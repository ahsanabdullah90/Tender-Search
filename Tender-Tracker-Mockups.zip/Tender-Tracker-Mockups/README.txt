TENDER TRACKER - REDESIGN MOCKUPS (sample data, for design review)

Best way to view: open the live Design canvas
  https://claude.ai/artifact/2UTZtcnepWhCxcp9pgppU3
The canvas has all boards laid out with their light and dark versions. Use
its Share / Export menu to download PNG or PDF copies of any board.

The files in this folder are the source for each board:
  Inbox-Dark / Main (Inbox light)   Inbox, triage list and detail panel
  Inbox-Empty                       Inbox with nothing to review (light)
  Pipeline-Light / Pipeline-Dark    Pipeline Board view (4 columns)
  Gantt-Light / Gantt-Dark          Pipeline Gantt view (5-week timeline)
  Sources-Keywords                  Sources & Keywords, Keywords tab
  Sources-Portals                   Sources & Keywords, Portals tab
  Sources-Data                      Sources & Keywords, Data tab
  canvas.json                       Layout index for the canvas

Note: these files load a small runtime (support.js) that only the Design
canvas provides, so double-clicking them will show a blank or broken page.
Use the canvas link above to view them.

All names, tenders, amounts and dates are sample data. Nothing is real.
See REDESIGN-HANDOVER.md for the plan these mockups follow.
